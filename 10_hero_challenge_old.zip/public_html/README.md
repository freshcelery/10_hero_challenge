10_hero_challenge
=================

Dota 2 10 hero challenge web app

Web application designed to emulate the 10 hero challenge portion of TI4's compendium 

Using the Dota 2 web api we will be grabbing a users match history information and testing to see if they won a match with a 
randomly generated list of heroes after the list was created.

More info to come soon.
